#include <stdio.h>
#include "RamSpace.h"

int main() {

   printf("Welcome to Test RamSpace\n");

   RamSpace *ramspace = new RamSpace(103);

   printf("got a ramspace\n");
   delete ramspace;
   return 0;
}
